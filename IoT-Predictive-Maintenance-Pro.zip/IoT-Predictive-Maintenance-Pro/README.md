# IoT Predictive Maintenance System

## Overview
ESP32-based system to monitor motor health using sensors and IoT.

## Features
- Real-time monitoring
- Fault detection
- ThingSpeak integration
- LCD + SD logging

## Images
![Circuit](images/circuit.png)
![Output](images/output.png)
